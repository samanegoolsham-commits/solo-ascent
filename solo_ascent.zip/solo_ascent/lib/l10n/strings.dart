// Shared UI strings (English + Persian). Screens also use inline
// s.tx('English', 'فارسی') pairs, so every visible text exists in both languages.
const Map<String, Map<String, String>> kStrings = {
  'en': {
    'app_title': 'Solo Ascent',
    'tagline': 'Arise, Hunter.',
    'choose_language': 'Choose Language',
    'continue': 'Continue',
    'home': 'Home Hub',
    'gates': 'Gates',
    'quests': 'Quests',
    'inventory': 'Inventory & Shop',
    'skills': 'Skills',
    'status': 'Hunter Status',
    'settings': 'Settings',
    'language': 'Language',
    'reset': 'Reset Progress',
  },
  'fa': {
    'app_title': 'صعود تنها',
    'tagline': 'برخیز، شکارچی.',
    'choose_language': 'انتخاب زبان',
    'continue': 'ادامه',
    'home': 'پایگاه',
    'gates': 'دروازه‌ها',
    'quests': 'ماموریت‌ها',
    'inventory': 'کوله‌پشتی و فروشگاه',
    'skills': 'مهارت‌ها',
    'status': 'وضعیت شکارچی',
    'settings': 'تنظیمات',
    'language': 'زبان',
    'reset': 'حذف پیشرفت',
  },
};

const Map<String, String> kClassFa = {
  'Shadow Blade': 'تیغه سایه',
  'Iron Colossus': 'غول آهنین',
  'Arcane Surge': 'خیزش جادویی',
  'System Overlord': 'فرمانروای سامانه',
};

const Map<String, String> kStatFa = {
  'STR': 'قدرت',
  'AGI': 'چابکی',
  'VIT': 'سرزندگی',
  'INT': 'هوش',
  'Sense': 'ادراک',
};
