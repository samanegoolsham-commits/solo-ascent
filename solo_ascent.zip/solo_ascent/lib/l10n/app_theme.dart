import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xFF0B1020);
  static const surface = Color(0xFF141B33);
  static const blue = Color(0xFF1E3A8A);
  static const crimson = Color(0xFFB91C1C);
  static const gold = Color(0xFFD4AF37);
  static const text = Color(0xFFE5E7EB);
  static const hp = Color(0xFFDC2626);
  static const mp = Color(0xFF2563EB);
}

final ThemeData appTheme = ThemeData(
  useMaterial3: true,
  brightness: Brightness.dark,
  fontFamily: 'Vazirmatn',
  scaffoldBackgroundColor: AppColors.bg,
  colorScheme: const ColorScheme.dark(
    primary: AppColors.gold,
    secondary: AppColors.crimson,
    surface: AppColors.surface,
    onSurface: AppColors.text,
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: AppColors.surface,
    foregroundColor: AppColors.gold,
    centerTitle: true,
  ),
  cardColor: AppColors.surface,
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: AppColors.blue,
      foregroundColor: AppColors.text,
      minimumSize: const Size.fromHeight(52),
      textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
  ),
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      foregroundColor: AppColors.gold,
      side: const BorderSide(color: AppColors.gold),
      minimumSize: const Size.fromHeight(48),
    ),
  ),
);
