class SystemWeapon {
  final String id, nameEn, nameFa, abilityEn, abilityFa;
  final double multiplier;
  final int usesPerGate, mpCost;

  /// Fraction of CURRENT HP sacrificed on use.
  final double hpCost;

  /// Fraction of enemy defense ignored.
  final double ignoreDef;
  final int stunTurns, freezeTurns;

  /// Can instantly kill weakened normal enemies; true damage on bosses.
  final bool execute;

  const SystemWeapon({
    required this.id,
    required this.nameEn,
    required this.nameFa,
    required this.abilityEn,
    required this.abilityFa,
    required this.multiplier,
    this.usesPerGate = 3,
    this.mpCost = 0,
    this.hpCost = 0,
    this.ignoreDef = 0,
    this.stunTurns = 0,
    this.freezeTurns = 0,
    this.execute = false,
  });
}
