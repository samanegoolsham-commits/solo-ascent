/// A monster, elite or boss that waits behind a Gate.
class Enemy {
  final String id, nameEn, nameFa;
  final int level, maxHp, attack, defense, expReward;
  final bool boss, elite;

  /// Status this enemy can inflict on the hunter: poison, stun, freeze or charm.
  final String status;

  /// Fraction of max HP regenerated every turn (0 = none).
  final double regen;

  const Enemy({
    required this.id,
    required this.nameEn,
    required this.nameFa,
    required this.level,
    required this.maxHp,
    required this.attack,
    required this.defense,
    required this.expReward,
    this.boss = false,
    this.elite = false,
    this.status = '',
    this.regen = 0,
  });
}
