class Player {
  static const List<String> ranks = [
    'E',
    'D',
    'C',
    'B',
    'A',
    'S',
    'National Level',
    'Monarch Candidate',
  ];
  static const List<String> ranksFa = [
    'E',
    'D',
    'C',
    'B',
    'A',
    'S',
    'سطح ملی',
    'نامزد پادشاهی',
  ];

  String name, hunterClass;
  int level, exp, statPoints, hp, mp, gold, ngPlus;
  bool cleared;
  Map<String, int> stats;
  List<String> skills, weapons, defeated, questClaimed;
  Map<String, int> inventory, questProgress;
  String dailyKey, weeklyKey;

  Player({
    this.name = 'Hunter',
    this.hunterClass = '',
    this.level = 1,
    this.exp = 0,
    this.statPoints = 0,
    this.hp = 100,
    this.mp = 40,
    this.gold = 0,
    this.ngPlus = 0,
    this.cleared = false,
    this.dailyKey = '',
    this.weeklyKey = '',
    Map<String, int>? stats,
    List<String>? skills,
    List<String>? weapons,
    List<String>? defeated,
    List<String>? questClaimed,
    Map<String, int>? inventory,
    Map<String, int>? questProgress,
  }) : stats = stats ?? {'STR': 8, 'AGI': 8, 'VIT': 8, 'INT': 8, 'Sense': 8},
       skills = skills ?? <String>[],
       weapons = weapons ?? <String>[],
       defeated = defeated ?? <String>[],
       questClaimed = questClaimed ?? <String>[],
       inventory = inventory ?? {'health_potion': 3, 'mana_potion': 2},
       questProgress = questProgress ?? <String, int>{};

  int get _rankIndex => (level ~/ 10).clamp(0, ranks.length - 1).toInt();
  String get rank => ranks[_rankIndex];
  String get rankFa => ranksFa[_rankIndex];

  int get maxHp => 80 + stats['VIT']! * 12 + level * 8;
  int get maxMp => 30 + stats['INT']! * 6;
  int get expToNext => level * 100;
  int get defense => stats['VIT']! * 2 + level;

  /// Basic attack power: STR for warriors, INT for mages.
  int get attack {
    final str = stats['STR']!;
    final intel = stats['INT']!;
    if (hunterClass == 'Arcane Surge') return (intel * 26) ~/ 10 + level * 3;
    if (hunterClass == 'System Overlord') {
      final best = str > intel ? str : intel;
      return (best * 28) ~/ 10 + level * 3;
    }
    return str * 3 + level * 3;
  }

  /// Critical hit chance (0.0 - 0.6).
  double get critChance {
    var c = 0.05 + stats['AGI']! * 0.008;
    if (hunterClass == 'Shadow Blade') c += 0.15;
    return c > 0.6 ? 0.6 : c;
  }

  /// Damage multiplier on a critical hit (assassins hit harder).
  double get critMultiplier => hunterClass == 'Shadow Blade' ? 2.1 : 1.75;

  /// Adds EXP and returns how many levels were gained.
  int gainExp(int amount) {
    exp += amount;
    var gained = 0;
    while (exp >= expToNext) {
      exp -= expToNext;
      level++;
      gained++;
      statPoints += 5;
    }
    if (gained > 0) {
      hp = maxHp;
      mp = maxMp;
    }
    return gained;
  }

  bool spendPoints(String key, int amount) {
    if (amount <= 0 || amount > statPoints || !stats.containsKey(key)) {
      return false;
    }
    stats[key] = stats[key]! + amount;
    statPoints -= amount;
    return true;
  }

  void fullHeal() {
    hp = maxHp;
    mp = maxMp;
  }

  Map<String, dynamic> toJson() => {
    'name': name,
    'hunterClass': hunterClass,
    'level': level,
    'exp': exp,
    'statPoints': statPoints,
    'hp': hp,
    'mp': mp,
    'gold': gold,
    'ngPlus': ngPlus,
    'cleared': cleared,
    'dailyKey': dailyKey,
    'weeklyKey': weeklyKey,
    'stats': stats,
    'skills': skills,
    'weapons': weapons,
    'defeated': defeated,
    'questClaimed': questClaimed,
    'inventory': inventory,
    'questProgress': questProgress,
  };

  factory Player.fromJson(Map<String, dynamic> j) {
    final defaults = Player();
    final loadedStats = Map<String, int>.from(j['stats'] ?? <String, int>{});
    for (final k in defaults.stats.keys) {
      loadedStats.putIfAbsent(k, () => 8);
    }
    final p = Player(
      name: (j['name'] ?? 'Hunter') as String,
      hunterClass: (j['hunterClass'] ?? '') as String,
      level: (j['level'] ?? 1) as int,
      exp: (j['exp'] ?? 0) as int,
      statPoints: (j['statPoints'] ?? 0) as int,
      hp: (j['hp'] ?? 100) as int,
      mp: (j['mp'] ?? 40) as int,
      gold: (j['gold'] ?? 0) as int,
      ngPlus: (j['ngPlus'] ?? 0) as int,
      cleared: (j['cleared'] ?? false) as bool,
      dailyKey: (j['dailyKey'] ?? '') as String,
      weeklyKey: (j['weeklyKey'] ?? '') as String,
      stats: loadedStats,
      skills: List<String>.from(j['skills'] ?? <String>[]),
      weapons: List<String>.from(j['weapons'] ?? <String>[]),
      defeated: List<String>.from(j['defeated'] ?? <String>[]),
      questClaimed: List<String>.from(j['questClaimed'] ?? <String>[]),
      inventory: Map<String, int>.from(
        j['inventory'] ?? {'health_potion': 3, 'mana_potion': 2},
      ),
      questProgress: Map<String, int>.from(
        j['questProgress'] ?? <String, int>{},
      ),
    );
    p.hp = p.hp.clamp(1, p.maxHp).toInt();
    p.mp = p.mp.clamp(0, p.maxMp).toInt();
    return p;
  }
}
