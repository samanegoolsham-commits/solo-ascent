class Quest {
  final String id, nameEn, nameFa;

  /// 'kill' = win any fight, 'elite' = defeat an elite or boss.
  final String kind;

  /// 'daily' or 'weekly'.
  final String period;
  final int target;

  /// Rewards are multiplied by the hunter's level when claimed.
  final int expPerLevel, goldPerLevel;

  /// Bonus item id ('' = none) and amount.
  final String rewardItem;
  final int rewardItemCount;

  const Quest({
    required this.id,
    required this.nameEn,
    required this.nameFa,
    required this.kind,
    required this.period,
    required this.target,
    required this.expPerLevel,
    required this.goldPerLevel,
    this.rewardItem = '',
    this.rewardItemCount = 0,
  });
}
