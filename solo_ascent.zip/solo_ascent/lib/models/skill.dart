class Skill {
  final String id, nameEn, nameFa, descEn, descFa;

  /// stun, freeze, poison or empty.
  final String status;

  /// Damage multiplier applied to the hunter's attack.
  final double multiplier;
  final int mpCost, cooldown;

  /// Class that learns this skill by level ('' = learned from a boss reward).
  final String hunterClass;

  /// Level at which the class learns it (0 = never learned automatically).
  final int unlockLevel;

  /// Fraction of the damage dealt that heals the hunter.
  final double drain;

  /// Halves the next enemy hit.
  final bool guard;

  const Skill({
    required this.id,
    required this.nameEn,
    required this.nameFa,
    required this.descEn,
    required this.descFa,
    required this.multiplier,
    this.mpCost = 0,
    this.cooldown = 0,
    this.status = '',
    this.hunterClass = '',
    this.unlockLevel = 0,
    this.drain = 0,
    this.guard = false,
  });
}
