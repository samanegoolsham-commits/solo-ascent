class GameItem {
  final String id, nameEn, nameFa, descriptionEn, descriptionFa;

  /// Percent of max HP restored (0 = none).
  final int healHp;

  /// Percent of max MP restored (0 = none).
  final int healMp;

  /// Shop price in gold.
  final int price;

  const GameItem({
    required this.id,
    required this.nameEn,
    required this.nameFa,
    required this.descriptionEn,
    required this.descriptionFa,
    this.healHp = 0,
    this.healMp = 0,
    this.price = 0,
  });
}
