import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/enemies_data.dart';
import '../l10n/strings.dart';
import '../models/enemy.dart';
import '../models/item.dart';
import '../models/player.dart';
import '../models/quest.dart';
import '../models/skill.dart';
import '../models/system_weapon.dart';
import 'game_engine.dart';

/// Glue between the pure game engine, local save data and the UI.
class AppState extends ChangeNotifier {
  AppState();

  static const String _saveKey = 'solo_ascent_save_v1';

  final GameEngine engine = GameEngine();
  String lang = 'en';
  bool langChosen = false;
  SharedPreferences? _prefs;

  // ------------------------------------------------------------------
  // Start-up / save
  // ------------------------------------------------------------------
  Future<void> init() async {
    try {
      _prefs = await SharedPreferences.getInstance();
      langChosen = _prefs!.containsKey('lang');
      lang = _prefs!.getString('lang') ?? 'en';
      final raw = _prefs!.getString(_saveKey);
      if (raw != null) {
        engine.player = Player.fromJson(
          jsonDecode(raw) as Map<String, dynamic>,
        );
      }
    } catch (_) {
      // Corrupt or unavailable storage: start with a fresh hunter.
      engine.player = Player();
    }
    if (engine.hasCharacter) engine.refreshQuests(DateTime.now());
  }

  Future<void> save() async {
    try {
      await _prefs?.setString(_saveKey, jsonEncode(engine.player.toJson()));
    } catch (_) {}
  }

  Future<void> setLang(String l) async {
    lang = l;
    langChosen = true;
    notifyListeners();
    try {
      await _prefs?.setString('lang', l);
    } catch (_) {}
  }

  Future<void> resetProgress() async {
    engine.player = Player();
    engine.inCombat = false;
    engine.enemy = null;
    try {
      await _prefs?.remove(_saveKey);
    } catch (_) {}
    notifyListeners();
  }

  // ------------------------------------------------------------------
  // Language helpers
  // ------------------------------------------------------------------
  bool get isFa => lang == 'fa';
  bool get fa => isFa;
  String t(String key) => kStrings[lang]?[key] ?? kStrings['en']![key] ?? key;
  String tx(String en, String faText) => isFa ? faText : en;

  String className(String id) => isFa ? (kClassFa[id] ?? id) : id;
  String statName(String key) => isFa ? (kStatFa[key] ?? key) : key;
  String get rankName => isFa ? player.rankFa : player.rank;
  String skillName(String id) {
    final s = engine.skillById(id);
    return s == null ? id : (isFa ? s.nameFa : s.nameEn);
  }

  String weaponName(String id) {
    final w = engine.weaponById(id);
    return w == null ? id : (isFa ? w.nameFa : w.nameEn);
  }

  String itemName(String id) {
    final i = engine.itemById(id);
    if (i != null) return isFa ? i.nameFa : i.nameEn;
    if (id == 'echo_fragment') return tx('Echo Fragment', 'قطعه پژواک');
    return id;
  }

  // ------------------------------------------------------------------
  // Read-only views of the engine
  // ------------------------------------------------------------------
  Player get player => engine.player;
  bool get hasCharacter => engine.hasCharacter;
  Enemy? get enemy => engine.enemy;
  int get enemyHp => engine.enemyHp;
  int get enemyMaxHp => engine.enemyMaxHp;
  bool get inCombat => engine.inCombat;
  bool get won => engine.won;
  bool get fled => engine.fled;
  bool get enraged => engine.enraged;
  int get enemySkip => engine.enemySkip;
  int get enemyPoison => engine.enemyPoison;
  int get playerSkip => engine.playerSkip;
  int get playerPoison => engine.playerPoison;
  CombatResult get result => engine.result;
  bool get canAwakenOverlord => engine.canAwakenOverlord;
  bool get canStartNewGamePlus => engine.canStartNewGamePlus;

  List<String> get combatLog =>
      engine.log.map((m) => isFa ? m.fa : m.en).toList();

  int cooldownOf(String skillId) => engine.cooldowns[skillId] ?? 0;
  int weaponUsesLeft(String weaponId) => engine.weaponUses[weaponId] ?? 0;
  bool isLocked(Enemy e) => engine.isLocked(e);
  bool isDefeated(String enemyId) => player.defeated.contains(enemyId);

  // Quests
  int questProgress(Quest q) => engine.questProgress(q);
  bool questClaimed(Quest q) => engine.questClaimed(q);
  bool questReady(Quest q) => engine.questReady(q);

  List<Enemy> get storyBosses => enemies.where((e) => e.boss).toList();

  // ------------------------------------------------------------------
  // Actions
  // ------------------------------------------------------------------
  Future<void> chooseClass(String cls, String name) async {
    engine.chooseClass(cls, name);
    await save();
    notifyListeners();
  }

  void refreshQuests() {
    if (!engine.hasCharacter) return;
    engine.refreshQuests(DateTime.now());
    save();
    notifyListeners();
  }

  bool claimQuest(Quest q) {
    final ok = engine.claimQuest(q);
    if (ok) save();
    notifyListeners();
    return ok;
  }

  void spendPoints(String key, int amount) {
    if (player.spendPoints(key, amount)) {
      player.fullHeal();
      save();
    }
    notifyListeners();
  }

  bool buy(GameItem item) {
    final ok = engine.buy(item);
    if (ok) save();
    notifyListeners();
    return ok;
  }

  void awakenOverlord() {
    engine.awakenOverlord();
    save();
    notifyListeners();
  }

  void startNewGamePlus() {
    engine.startNewGamePlus();
    save();
    notifyListeners();
  }

  void enterGate(Enemy e) {
    engine.enterGate(e);
    notifyListeners();
  }

  void _afterCombatAction() {
    if (!engine.inCombat) save();
    notifyListeners();
  }

  void basicAttack() {
    engine.basicAttack();
    _afterCombatAction();
  }

  void useSkill(Skill sk) {
    engine.useSkill(sk);
    _afterCombatAction();
  }

  void useItem(GameItem it) {
    engine.useItem(it);
    _afterCombatAction();
  }

  void useWeapon(SystemWeapon w) {
    engine.useWeapon(w);
    _afterCombatAction();
  }

  void flee() {
    engine.flee();
    _afterCombatAction();
  }
}

extension Tr on BuildContext {
  String tr(String key) => read<AppState>().t(key);
  AppState get app => read<AppState>();
}
