import 'dart:math';

import '../data/items_data.dart';
import '../data/quests_data.dart';
import '../data/skills_data.dart';
import '../data/system_weapons_data.dart';
import '../models/enemy.dart';
import '../models/item.dart';
import '../models/player.dart';
import '../models/quest.dart';
import '../models/skill.dart';
import '../models/system_weapon.dart';

/// A bilingual message shown in the combat log.
class Msg {
  final String en, fa;
  const Msg(this.en, this.fa);
}

/// What the hunter earned from a finished fight.
class CombatResult {
  int exp = 0, gold = 0, levels = 0;
  List<String> newSkills = [];
  List<String> newWeapons = [];
  Map<String, int> loot = {};
  List<Msg> notes = [];
  bool trueEnding = false;
  bool gameCleared = false;
}

/// Pure-Dart game rules (no Flutter imports) so they can be tested anywhere.
class GameEngine {
  GameEngine({Random? random}) : rng = random ?? Random();

  final Random rng;
  Player player = Player();

  // ---- current fight ----
  Enemy? enemy;
  int enemyHp = 0, enemyMaxHp = 0, enemyAtk = 0, enemyDef = 0;
  bool inCombat = false, won = false, fled = false;
  bool enraged = false, phase2 = false;
  int enemySkip = 0, enemyPoison = 0, playerSkip = 0, playerPoison = 0;
  bool guard = false;
  final Map<String, int> cooldowns = {};
  final Map<String, int> weaponUses = {};
  List<Msg> log = [];
  CombatResult result = CombatResult();
  bool _crit = false;

  bool get hasCharacter => player.hunterClass.isNotEmpty;

  void _say(String en, String fa) {
    log.add(Msg(en, fa));
    if (log.length > 60) log.removeAt(0);
  }

  // ------------------------------------------------------------------
  // Character
  // ------------------------------------------------------------------
  void chooseClass(String cls, String name) {
    final p = Player(
      name: name.trim().isEmpty ? 'Hunter' : name.trim(),
      hunterClass: cls,
    );
    if (cls == 'Shadow Blade') {
      p.stats['AGI'] = p.stats['AGI']! + 4;
      p.stats['STR'] = p.stats['STR']! + 2;
    } else if (cls == 'Iron Colossus') {
      p.stats['VIT'] = p.stats['VIT']! + 4;
      p.stats['STR'] = p.stats['STR']! + 2;
    } else if (cls == 'Arcane Surge') {
      p.stats['INT'] = p.stats['INT']! + 4;
      p.stats['Sense'] = p.stats['Sense']! + 2;
    }
    player = p;
    _unlockSkills();
    p.fullHeal();
    refreshQuests(DateTime.now());
  }

  bool get canAwakenOverlord =>
      hasCharacter &&
      player.level >= 50 &&
      player.hunterClass != 'System Overlord';

  void awakenOverlord() {
    if (!canAwakenOverlord) return;
    player.hunterClass = 'System Overlord';
    _unlockSkills();
  }

  /// Teaches every skill the hunter's class has reached. Returns new skill ids.
  List<String> _unlockSkills() {
    final added = <String>[];
    for (final sk in skills) {
      if (sk.unlockLevel <= 0) continue;
      final mine =
          sk.hunterClass == player.hunterClass ||
          player.hunterClass == 'System Overlord';
      if (mine &&
          player.level >= sk.unlockLevel &&
          !player.skills.contains(sk.id)) {
        player.skills.add(sk.id);
        added.add(sk.id);
      }
    }
    return added;
  }

  bool get canStartNewGamePlus => hasCharacter && player.cleared;

  void startNewGamePlus() {
    if (!canStartNewGamePlus) return;
    player.ngPlus++;
    player.cleared = false;
    player.defeated.clear();
    player.fullHeal();
  }

  bool buy(GameItem item) {
    if (item.price <= 0 || player.gold < item.price) return false;
    final have = player.inventory[item.id] ?? 0;
    if (have >= 99) return false;
    player.gold -= item.price;
    player.inventory[item.id] = have + 1;
    return true;
  }

  // ------------------------------------------------------------------
  // Quests
  // ------------------------------------------------------------------
  void refreshQuests(DateTime now) {
    final day = '${now.year}-${now.month}-${now.day}';
    final week = '${now.difference(DateTime(1970)).inDays ~/ 7}';
    if (player.dailyKey != day) {
      _resetPeriod('daily');
      player.dailyKey = day;
    }
    if (player.weeklyKey != week) {
      _resetPeriod('weekly');
      player.weeklyKey = week;
    }
  }

  void _resetPeriod(String period) {
    for (final q in quests) {
      if (q.period != period) continue;
      player.questProgress.remove(q.id);
      player.questClaimed.remove(q.id);
    }
  }

  int questProgress(Quest q) {
    final v = player.questProgress[q.id] ?? 0;
    return v > q.target ? q.target : v;
  }

  bool questClaimed(Quest q) => player.questClaimed.contains(q.id);
  bool questReady(Quest q) => !questClaimed(q) && questProgress(q) >= q.target;

  bool claimQuest(Quest q) {
    if (!questReady(q)) return false;
    player.questClaimed.add(q.id);
    final lvl = player.level;
    player.gold += q.goldPerLevel * lvl;
    if (q.rewardItem.isNotEmpty) {
      player.inventory[q.rewardItem] =
          (player.inventory[q.rewardItem] ?? 0) + q.rewardItemCount;
    }
    final before = player.rank;
    player.gainExp(q.expPerLevel * lvl);
    _unlockSkills();
    if (player.rank != before) player.statPoints += 5;
    return true;
  }

  void _countQuests(Enemy e) {
    for (final q in quests) {
      final counts =
          q.kind == 'kill' || (q.kind == 'elite' && (e.elite || e.boss));
      if (counts) {
        player.questProgress[q.id] = (player.questProgress[q.id] ?? 0) + 1;
      }
    }
  }

  // ------------------------------------------------------------------
  // Gates
  // ------------------------------------------------------------------
  /// Gates far above the hunter's level are locked.
  bool isLocked(Enemy e) => e.level > player.level + 3;

  void enterGate(Enemy e) {
    final scale = pow(1.5, player.ngPlus).toDouble();
    enemy = e;
    enemyMaxHp = (e.maxHp * scale).round();
    enemyHp = enemyMaxHp;
    enemyAtk = (e.attack * scale).round();
    enemyDef = (e.defense * scale).round();
    player.fullHeal();
    inCombat = true;
    won = false;
    fled = false;
    enraged = false;
    phase2 = false;
    enemySkip = 0;
    enemyPoison = 0;
    playerSkip = 0;
    playerPoison = 0;
    guard = false;
    cooldowns.clear();
    weaponUses.clear();
    for (final w in systemWeapons) {
      weaponUses[w.id] = w.usesPerGate;
    }
    log = [];
    result = CombatResult();
    _say('${e.nameEn} blocks your path!', '${e.nameFa} راهت را سد می‌کند!');
  }

  // ------------------------------------------------------------------
  // Player actions
  // ------------------------------------------------------------------
  int _hit(double mult, {double ignoreDef = 0, double critBonus = 0}) {
    _crit = false;
    var d =
        player.attack * mult * (0.9 + rng.nextDouble() * 0.2) -
        enemyDef * (1 - ignoreDef) / 2;
    if (rng.nextDouble() < player.critChance + critBonus) {
      d *= player.critMultiplier;
      _crit = true;
    }
    final dmg = d.round();
    return dmg < 1 ? 1 : dmg;
  }

  String get _critEn => _crit ? ' (CRIT!)' : '';
  String get _critFa => _crit ? ' (ضربه بحرانی!)' : '';

  void _damageEnemy(int d) {
    enemyHp = max(0, enemyHp - d);
  }

  void basicAttack() => _turn(() {
    final d = _hit(1.0);
    _damageEnemy(d);
    _say(
      'You strike ${enemy!.nameEn} for $d damage.$_critEn',
      'به ${enemy!.nameFa} $d آسیب زدی.$_critFa',
    );
    return true;
  });

  void useSkill(Skill sk) => _turn(() {
    if (!player.skills.contains(sk.id)) return false;
    if ((cooldowns[sk.id] ?? 0) > 0) {
      _say(
        '${sk.nameEn} is still recharging!',
        '${sk.nameFa} هنوز آماده نیست!',
      );
      return false;
    }
    if (player.mp < sk.mpCost) {
      _say('Not enough MP!', 'مانا کافی نیست!');
      return false;
    }
    player.mp -= sk.mpCost;
    final d = _hit(sk.multiplier);
    _damageEnemy(d);
    _say(
      '${sk.nameEn} hits for $d damage!$_critEn',
      '${sk.nameFa} $d آسیب زد!$_critFa',
    );
    if (sk.cooldown > 0) cooldowns[sk.id] = sk.cooldown + 1;
    if (sk.drain > 0) {
      final h = (d * sk.drain).round();
      player.hp = min(player.maxHp, player.hp + h);
      _say('You drain $h HP.', '$h سلامتی جذب کردی.');
    }
    if (sk.guard) {
      guard = true;
      _say('You brace for the next hit.', 'برای ضربه بعدی آماده می‌شوی.');
    }
    _applyStatus(sk.status);
    return true;
  });

  void _applyStatus(String st) {
    if (st.isEmpty || enemyHp <= 0) return;
    final e = enemy!;
    final chance = e.boss ? 0.25 : 0.45;
    if (st == 'poison') {
      enemyPoison = 3;
      _say('${e.nameEn} is poisoned!', '${e.nameFa} مسموم شد!');
    } else if (st == 'stun' && rng.nextDouble() < chance) {
      enemySkip = max(enemySkip, 1);
      _say('${e.nameEn} is stunned!', '${e.nameFa} گیج شد!');
    } else if (st == 'freeze' && rng.nextDouble() < chance) {
      enemySkip = max(enemySkip, 1);
      _say('${e.nameEn} is frozen!', '${e.nameFa} یخ زد!');
    }
  }

  void useItem(GameItem it) => _turn(() {
    final have = player.inventory[it.id] ?? 0;
    if (have <= 0) return false;
    player.inventory[it.id] = have - 1;
    if (it.healHp > 0) {
      final h = (player.maxHp * it.healHp / 100).round();
      player.hp = min(player.maxHp, player.hp + h);
      _say(
        'You drink ${it.nameEn}: +$h HP.',
        '${it.nameFa} نوشیدی: +$h سلامتی.',
      );
    }
    if (it.healMp > 0) {
      final m = (player.maxMp * it.healMp / 100).round();
      player.mp = min(player.maxMp, player.mp + m);
      _say('You drink ${it.nameEn}: +$m MP.', '${it.nameFa} نوشیدی: +$m مانا.');
    }
    if (it.id == 'antidote') {
      if (playerPoison > 0) {
        playerPoison = 0;
        _say('The poison is cured.', 'مسمومیت درمان شد.');
      } else {
        _say(
          'You drink the antidote (not poisoned).',
          'پادزهر را نوشیدی (مسموم نبودی).',
        );
      }
    }
    return true;
  });

  void useWeapon(SystemWeapon w) => _turn(() {
    if (!player.weapons.contains(w.id)) return false;
    if ((weaponUses[w.id] ?? 0) <= 0) {
      _say(
        '${w.nameEn} has no uses left in this Gate.',
        '${w.nameFa} در این دروازه دیگر قابل استفاده نیست.',
      );
      return false;
    }
    if (player.mp < w.mpCost) {
      _say('Not enough MP!', 'مانا کافی نیست!');
      return false;
    }
    var hpCost = 0;
    if (w.hpCost > 0) {
      hpCost = (player.hp * w.hpCost).round();
      if (player.hp - hpCost < 1) {
        _say(
          'Too weak to wield ${w.nameEn}!',
          'برای استفاده از ${w.nameFa} خیلی ضعیفی!',
        );
        return false;
      }
    }
    player.mp -= w.mpCost;
    player.hp -= hpCost;
    weaponUses[w.id] = weaponUses[w.id]! - 1;
    final e = enemy!;
    if (hpCost > 0) {
      _say(
        '${w.nameEn} drains $hpCost of your HP!',
        '${w.nameFa} $hpCost از سلامتی‌ات را می‌گیرد!',
      );
    }
    if (w.execute &&
        !e.boss &&
        enemyHp * 4 < enemyMaxHp &&
        rng.nextDouble() < 0.6) {
      enemyHp = 0;
      _say(
        '${w.abilityEn}! ${e.nameEn} is executed!',
        '${w.abilityFa}! ${e.nameFa} نابود شد!',
      );
      return true;
    }
    final ignore = (w.execute && e.boss) ? 1.0 : w.ignoreDef;
    final d = _hit(
      w.multiplier,
      ignoreDef: ignore,
      critBonus: w.execute ? 0.2 : 0,
    );
    _damageEnemy(d);
    _say(
      '${w.abilityEn}! $d damage.$_critEn',
      '${w.abilityFa}! $d آسیب.$_critFa',
    );
    if (w.stunTurns > 0) {
      enemySkip = max(enemySkip, w.stunTurns);
      _say('${e.nameEn} is stunned!', '${e.nameFa} گیج شد!');
    }
    if (w.freezeTurns > 0) {
      enemySkip = max(enemySkip, e.boss ? 1 : w.freezeTurns);
      _say('${e.nameEn} is frozen solid!', '${e.nameFa} کاملاً یخ زد!');
    }
    return true;
  });

  void flee() => _turn(() {
    final e = enemy!;
    var chance = 0.35 + (player.stats['AGI']! - e.level * 0.5) / 60;
    chance = chance.clamp(0.1, 0.85).toDouble();
    if (e.boss) chance *= 0.5;
    if (rng.nextDouble() < chance) {
      inCombat = false;
      fled = true;
      won = false;
      _say('You escaped the Gate!', 'از دروازه فرار کردی!');
      player.fullHeal();
    } else {
      _say('You failed to escape!', 'فرار ناموفق بود!');
    }
    return true;
  });

  // ------------------------------------------------------------------
  // Turn flow
  // ------------------------------------------------------------------
  void _turn(bool Function() act) {
    if (!inCombat) return;
    if (playerSkip > 0) {
      playerSkip--;
      _say(
        'You cannot move! Your turn is lost.',
        'نمی‌توانی حرکت کنی! نوبتت از دست رفت.',
      );
    } else if (!act()) {
      return; // invalid action: no turn used
    }
    if (!inCombat) return; // fled
    if (_checkEnemyDead()) return;
    _enemyPhase();
    if (!inCombat) return;
    cooldowns.updateAll((k, v) => v > 0 ? v - 1 : 0);
  }

  bool _checkEnemyDead() {
    if (enemyHp > 0) return false;
    final e = enemy!;
    if (e.id == 'architect' && !phase2 && _hasAllSystemWeapons) {
      phase2 = true;
      enemyHp = (enemyMaxHp * 0.6).round();
      enemyAtk = (enemyAtk * 1.2).round();
      enemySkip = 0;
      enemyPoison = 0;
      _say(
        'The four System Weapons resonate! The Architect rises again - SECRET PHASE!',
        'چهار سلاح سامانه طنین می‌اندازند! معمار دوباره برمی‌خیزد - مرحله مخفی!',
      );
      return false;
    }
    _win();
    return true;
  }

  bool get _hasAllSystemWeapons =>
      systemWeapons.every((w) => player.weapons.contains(w.id));

  void _enemyPhase() {
    final e = enemy!;
    if (enemyPoison > 0) {
      enemyPoison--;
      final d = max(5, (player.attack * 0.25).round());
      _damageEnemy(d);
      _say(
        '${e.nameEn} suffers $d poison damage.',
        '${e.nameFa} $d آسیب سم دید.',
      );
      if (_checkEnemyDead()) return;
    }
    if (e.regen > 0 && enemyHp > 0 && enemyHp < enemyMaxHp) {
      final h = (enemyMaxHp * e.regen).round();
      enemyHp = min(enemyMaxHp, enemyHp + h);
      _say(
        '${e.nameEn} regenerates $h HP.',
        '${e.nameFa} $h سلامتی بازیابی کرد.',
      );
    }
    if (e.boss && !enraged && enemyHp * 2 <= enemyMaxHp) {
      enraged = true;
      enemyAtk = (enemyAtk * 1.25).round();
      _say('${e.nameEn} is ENRAGED!', '${e.nameFa} خشمگین شد!');
    }
    if (enemySkip > 0) {
      enemySkip--;
      _say('${e.nameEn} cannot act!', '${e.nameFa} نمی‌تواند حرکت کند!');
    } else {
      _enemyAttack();
    }
    if (player.hp > 0 && playerPoison > 0) {
      playerPoison--;
      final d = max(3, (player.maxHp * 0.04).round());
      player.hp = max(0, player.hp - d);
      _say('Poison deals $d damage to you.', 'سم $d آسیب به تو زد.');
    }
    if (player.hp <= 0) _lose();
  }

  void _enemyAttack() {
    final e = enemy!;
    var d = enemyAtk * (0.9 + rng.nextDouble() * 0.2) - player.defense / 2;
    if (guard) {
      d *= 0.5;
      guard = false;
      _say(
        'Your guard absorbs part of the blow.',
        'دفاعت بخشی از ضربه را جذب کرد.',
      );
    }
    final dmg = max(1, d.round());
    player.hp = max(0, player.hp - dmg);
    _say(
      '${e.nameEn} hits you for $dmg damage.',
      '${e.nameFa} $dmg آسیب به تو زد.',
    );
    if (player.hp > 0 && e.status.isNotEmpty && rng.nextDouble() < 0.3) {
      if (e.status == 'poison') {
        playerPoison = 3;
        _say('You are poisoned!', 'مسموم شدی!');
      } else if (e.status == 'stun') {
        playerSkip = 1;
        _say('You are stunned!', 'گیج شدی!');
      } else if (e.status == 'freeze') {
        playerSkip = 1;
        _say('You are frozen!', 'یخ زدی!');
      } else if (e.status == 'charm') {
        playerSkip = 1;
        _say(
          'You are charmed and lose your will!',
          'افسون شدی و اراده‌ات را از دست دادی!',
        );
      }
    }
  }

  void _lose() {
    inCombat = false;
    won = false;
    fled = false;
    _say('You have fallen...', 'شکست خوردی...');
    player.fullHeal();
  }

  // ------------------------------------------------------------------
  // Victory
  // ------------------------------------------------------------------
  void _win() {
    final e = enemy!;
    inCombat = false;
    won = true;
    fled = false;
    final r = CombatResult();
    result = r;
    final scale = pow(1.5, player.ngPlus).toDouble();

    var exp = e.expReward * scale;
    if (player.level > e.level + 15) {
      exp *= 0.2;
    } else if (player.level > e.level + 6) {
      exp *= 0.5;
    }
    r.exp = max(1, exp.round());
    final goldBase = e.boss
        ? e.level * 30
        : (e.elite ? e.level * 10 : e.level * 4 + 5);
    r.gold = (goldBase * scale).round();
    player.gold += r.gold;

    final rankBefore = player.rank;
    r.levels = player.gainExp(r.exp);
    r.newSkills.addAll(_unlockSkills());
    if (player.rank != rankBefore) {
      player.statPoints += 5;
      r.notes.add(
        Msg(
          'Rank promotion: ${player.rank}-Rank! (+5 stat points)',
          'ارتقای رتبه: رتبه ${player.rankFa}! (+۵ امتیاز ویژگی)',
        ),
      );
    }

    // loot
    final luck = player.stats['Sense']! * 0.005;
    void roll(String id, double p) {
      if (rng.nextDouble() < p) _addLoot(r, id, 1);
    }

    roll('health_potion', 0.55 + luck);
    roll('mana_potion', 0.40 + luck);
    roll('antidote', 0.15 + luck);
    if (e.boss) _addLoot(r, 'health_potion', 2);

    _storyRewards(e, r);

    if (!player.defeated.contains(e.id)) player.defeated.add(e.id);
    _countQuests(e);
    player.fullHeal();
    _say('${e.nameEn} is defeated!', '${e.nameFa} شکست خورد!');
  }

  void _addLoot(CombatResult r, String id, int n) {
    final have = player.inventory[id] ?? 0;
    final add = min(n, 99 - have);
    if (add <= 0) return;
    player.inventory[id] = have + add;
    r.loot[id] = (r.loot[id] ?? 0) + add;
  }

  void _grantSkill(CombatResult r, String id) {
    if (player.skills.contains(id)) return;
    player.skills.add(id);
    r.newSkills.add(id);
  }

  void _grantWeapon(CombatResult r, String id) {
    if (player.weapons.contains(id)) return;
    player.weapons.add(id);
    r.newWeapons.add(id);
  }

  void _storyRewards(Enemy e, CombatResult r) {
    final first = !player.defeated.contains(e.id);
    switch (e.id) {
      case 'cerberus':
        _grantSkill(r, 'system_slash');
        break;
      case 'bloodfang':
        _grantWeapon(r, 'shadow_reaper');
        _grantSkill(r, 'shadow_extraction');
        break;
      case 'iron_monarch':
        _grantWeapon(r, 'titanbreaker');
        if (first) {
          player.stats['VIT'] = player.stats['VIT']! + 5;
          r.notes.add(
            const Msg(
              'Colossus Core absorbed: +5 VIT permanently!',
              'هسته غول جذب شد: ۵ واحد سرزندگی دائمی!',
            ),
          );
        }
        break;
      case 'frozen_sovereign':
        _grantWeapon(r, 'frostbite');
        if (first) {
          player.statPoints += 10;
          r.notes.add(
            const Msg(
              'Frost Sovereign Armor claimed: +10 stat points!',
              'زره فرمانروای یخ به دست آمد: +۱۰ امتیاز ویژگی!',
            ),
          );
        }
        break;
      case 'echo_architect':
        _addLoot(r, 'echo_fragment', 1);
        r.notes.add(
          Msg(
            'Echo Fragment collected (${player.inventory['echo_fragment'] ?? 0}/3).',
            'قطعه پژواک جمع شد (${player.inventory['echo_fragment'] ?? 0}/۳).',
          ),
        );
        final three = [
          'shadow_reaper',
          'titanbreaker',
          'frostbite',
        ].every((id) => player.weapons.contains(id));
        if (three && (player.inventory['echo_fragment'] ?? 0) >= 3) {
          _grantWeapon(r, 'architect_judgement');
        }
        break;
      case 'architect':
        player.cleared = true;
        r.gameCleared = true;
        r.trueEnding = phase2;
        break;
    }
  }

  // ------------------------------------------------------------------
  // Lookups
  // ------------------------------------------------------------------
  Skill? skillById(String id) {
    for (final s in skills) {
      if (s.id == id) return s;
    }
    return null;
  }

  GameItem? itemById(String id) {
    for (final i in items) {
      if (i.id == id) return i;
    }
    return null;
  }

  SystemWeapon? weaponById(String id) {
    for (final w in systemWeapons) {
      if (w.id == id) return w;
    }
    return null;
  }
}
