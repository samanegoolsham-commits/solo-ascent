import 'package:flutter/material.dart';

class HpBar extends StatelessWidget {
  final String label;
  final int value, max;
  final Color color;

  const HpBar({
    super.key,
    required this.label,
    required this.value,
    required this.max,
    this.color = Colors.red,
  });

  @override
  Widget build(BuildContext context) {
    final ratio = max <= 0 ? 0.0 : (value / max).clamp(0.0, 1.0).toDouble();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Text(label), Text('$value / $max')],
        ),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(
            value: ratio,
            minHeight: 12,
            backgroundColor: Colors.white12,
            color: color,
          ),
        ),
      ],
    );
  }
}
