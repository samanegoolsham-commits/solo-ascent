import 'package:flutter/material.dart';

/// Small coloured label used for BOSS / ELITE / status effects.
class TagChip extends StatelessWidget {
  final String text;
  final Color color;

  const TagChip(this.text, this.color, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        border: Border.all(color: color),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(text, style: TextStyle(color: color, fontSize: 12)),
    );
  }
}
