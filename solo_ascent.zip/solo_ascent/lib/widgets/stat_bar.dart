import 'package:flutter/material.dart';

class StatBar extends StatelessWidget {
  final String label;
  final int value, max;

  const StatBar({
    super.key,
    required this.label,
    required this.value,
    required this.max,
  });

  @override
  Widget build(BuildContext context) {
    final ratio = max == 0 ? 0.0 : (value / max).clamp(0.0, 1.0).toDouble();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          SizedBox(
            width: 72,
            child: Text(label, style: const TextStyle(color: Colors.white70)),
          ),
          Expanded(
            child: LinearProgressIndicator(
              value: ratio,
              minHeight: 8,
              color: const Color(0xFFD4AF37),
              backgroundColor: Colors.white12,
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(width: 34, child: Text('$value')),
        ],
      ),
    );
  }
}
