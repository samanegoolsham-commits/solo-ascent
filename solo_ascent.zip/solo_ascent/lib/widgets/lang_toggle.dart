import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/app_state.dart';

class LangToggle extends StatelessWidget {
  const LangToggle({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return TextButton(
      onPressed: () => app.setLang(app.isFa ? 'en' : 'fa'),
      child: Text(
        app.isFa ? 'EN' : 'FA',
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
    );
  }
}
