import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/app_theme.dart';
import '../services/app_state.dart';
import 'home_hub_screen.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final e = s.enemy;
    final r = s.result;
    final won = s.won;
    final fled = s.fled;

    String title;
    IconData icon;
    Color color;
    if (won) {
      title = s.tx('VICTORY', 'پیروزی');
      icon = Icons.emoji_events;
      color = AppColors.gold;
    } else if (fled) {
      title = s.tx('ESCAPED', 'فرار موفق');
      icon = Icons.directions_run;
      color = Colors.lightBlueAccent;
    } else {
      title = s.tx('DEFEAT', 'شکست');
      icon = Icons.warning_amber_rounded;
      color = AppColors.crimson;
    }

    final lines = <Widget>[];
    void add(String text, {Color? c, double size = 16}) {
      lines.add(
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(color: c ?? Colors.white70, fontSize: size),
          ),
        ),
      );
    }

    if (won) {
      add('+${r.exp} EXP   •   +${r.gold} ${s.tx('Gold', 'طلا')}', size: 17);
      if (r.levels > 0) {
        add(
          '${s.tx('LEVEL UP!', 'ارتقای سطح!')} ${s.tx('Level', 'سطح')} ${s.player.level}'
          '  (+${r.levels * 5} ${s.tx('stat points', 'امتیاز ویژگی')})',
          c: AppColors.gold,
          size: 18,
        );
      }
      for (final id in r.newSkills) {
        add(
          '${s.tx('New skill', 'مهارت جدید')}: ${s.skillName(id)}',
          c: Colors.lightGreenAccent,
        );
      }
      for (final id in r.newWeapons) {
        add(
          '${s.tx('System Weapon obtained', 'سلاح سامانه به دست آمد')}: ${s.weaponName(id)}',
          c: AppColors.gold,
          size: 17,
        );
      }
      r.loot.forEach((id, n) {
        add('${s.tx('Loot', 'غنیمت')}: ${s.itemName(id)} ×$n');
      });
      for (final m in r.notes) {
        add(s.fa ? m.fa : m.en, c: Colors.lightBlueAccent);
      }
      if (r.gameCleared) {
        add(
          r.trueEnding
              ? s.tx(
                  'TRUE ENDING! The Architect falls, and the origin of the System is revealed. New Game+ is unlocked.',
                  'پایان حقیقی! معمار سقوط می‌کند و ریشه‌ی سامانه آشکار می‌شود. بازی جدید+ باز شد.',
                )
              : s.tx(
                  'The Architect falls. Collect all four System Weapons and return for the true ending. New Game+ is unlocked.',
                  'معمار سقوط می‌کند. برای پایان حقیقی هر چهار سلاح سامانه را جمع کن و برگرد. بازی جدید+ باز شد.',
                ),
          c: AppColors.gold,
          size: 17,
        );
      }
    } else if (!fled) {
      add(
        s.tx(
          'You fell in battle. Train, upgrade your stats and try again.',
          'در نبرد شکست خوردی. تمرین کن، ویژگی‌هایت را ارتقا بده و دوباره امتحان کن.',
        ),
      );
    } else {
      add(
        s.tx('You live to fight another day.', 'برای نبردی دیگر زنده ماندی.'),
      );
    }
    if (s.player.statPoints > 0) {
      add(
        '${s.player.statPoints} ${s.tx('stat points available', 'امتیاز ویژگی در دسترس')}',
        c: AppColors.gold,
      );
    }

    return PopScope(
      canPop: false,
      child: Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, size: 86, color: color),
                  const SizedBox(height: 12),
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      color: color,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    e == null ? '' : (s.fa ? e.nameFa : e.nameEn),
                    style: const TextStyle(fontSize: 19),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 10),
                  ...lines,
                  const SizedBox(height: 22),
                  ElevatedButton.icon(
                    onPressed: () => Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (_) => const HomeHubScreen()),
                      (route) => false,
                    ),
                    icon: const Icon(Icons.home),
                    label: Text(s.tx('Return to Hub', 'بازگشت به پایگاه')),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
