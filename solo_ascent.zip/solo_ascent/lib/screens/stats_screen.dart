import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/app_theme.dart';
import '../services/app_state.dart';
import '../widgets/stat_bar.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final p = s.player;
    final keys = p.stats.keys.toList();
    return Scaffold(
      appBar: AppBar(title: Text(s.t('status'))),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            '${p.name}  •  ${s.className(p.hunterClass)}',
            style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(
            '${s.tx('Level', 'سطح')} ${p.level}     ${s.tx('Rank', 'رتبه')} ${s.rankName}',
          ),
          const SizedBox(height: 14),
          for (final k in keys)
            StatBar(label: s.statName(k), value: p.stats[k]!, max: 100),
          const Divider(height: 28),
          Text(
            '${s.tx('HP', 'سلامتی')} ${p.maxHp}   •   ${s.tx('MP', 'مانا')} ${p.maxMp}',
          ),
          const SizedBox(height: 4),
          Text(
            '${s.tx('Attack', 'حمله')}: ${p.attack}   •   ${s.tx('Defense', 'دفاع')}: ${p.defense}   •   ${s.tx('Crit', 'بحرانی')}: ${(p.critChance * 100).round()}%',
          ),
          const SizedBox(height: 16),
          Text(
            '${s.tx('Unassigned points', 'امتیاز تخصیص‌نیافته')}: ${p.statPoints}',
            style: const TextStyle(color: AppColors.gold, fontSize: 17),
          ),
          const SizedBox(height: 8),
          for (final k in keys)
            Card(
              child: ListTile(
                title: Text(s.statName(k)),
                subtitle: Text(
                  '${s.tx('Current', 'فعلی')}: ${p.stats[k]}  •  ${_hint(s, k)}',
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      onPressed: p.statPoints >= 1
                          ? () => s.spendPoints(k, 1)
                          : null,
                      icon: const Icon(Icons.add_circle, color: AppColors.gold),
                    ),
                    IconButton(
                      onPressed: p.statPoints >= 5
                          ? () => s.spendPoints(k, 5)
                          : null,
                      icon: const Icon(Icons.keyboard_double_arrow_up),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  String _hint(AppState s, String k) {
    switch (k) {
      case 'STR':
        return s.tx('physical attack', 'حمله فیزیکی');
      case 'AGI':
        return s.tx('crit and flee chance', 'شانس بحرانی و فرار');
      case 'VIT':
        return s.tx('max HP and defense', 'سلامتی و دفاع');
      case 'INT':
        return s.tx('max MP, mage attack', 'مانا و حمله جادویی');
      default:
        return s.tx('better loot', 'غنیمت بهتر');
    }
  }
}
