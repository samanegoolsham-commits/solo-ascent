import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/app_theme.dart';
import '../services/app_state.dart';
import '../widgets/lang_toggle.dart';
import 'class_select_screen.dart';
import 'gate_select_screen.dart';
import 'inventory_screen.dart';
import 'quests_screen.dart';
import 'settings_screen.dart';
import 'skills_screen.dart';
import 'stats_screen.dart';

/// First screen after language choice: new hunters pick a class first.
Widget homeOrClassSelect(AppState s) =>
    s.hasCharacter ? const HomeHubScreen() : const ClassSelectScreen();

class HomeHubScreen extends StatelessWidget {
  const HomeHubScreen({super.key});

  void _open(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final p = s.player;
    return Scaffold(
      appBar: AppBar(title: Text(s.t('home')), actions: const [LangToggle()]),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p.name,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        color: AppColors.gold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${s.className(p.hunterClass)}  •  ${s.tx('Level', 'سطح')} ${p.level}  •  ${s.tx('Rank', 'رتبه')} ${s.rankName}',
                    ),
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: (p.exp / p.expToNext).clamp(0.0, 1.0).toDouble(),
                        minHeight: 10,
                        color: AppColors.gold,
                        backgroundColor: Colors.white12,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'EXP ${p.exp} / ${p.expToNext}',
                      style: const TextStyle(
                        color: Colors.white60,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(
                          Icons.monetization_on,
                          color: AppColors.gold,
                          size: 18,
                        ),
                        const SizedBox(width: 6),
                        Text('${p.gold}'),
                        const Spacer(),
                        if (p.ngPlus > 0)
                          Text(
                            'NG+${p.ngPlus}',
                            style: const TextStyle(color: AppColors.crimson),
                          ),
                      ],
                    ),
                    if (p.statPoints > 0)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text(
                          '${s.tx('Unspent stat points', 'امتیاز ویژگی خرج‌نشده')}: ${p.statPoints}',
                          style: const TextStyle(color: AppColors.gold),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.crimson,
              ),
              onPressed: () => _open(context, const GateSelectScreen()),
              icon: const Icon(Icons.door_front_door),
              label: Text(s.t('gates')),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: () => _open(context, const QuestsScreen()),
              icon: const Icon(Icons.assignment),
              label: Text(s.t('quests')),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: () => _open(context, const StatsScreen()),
              icon: const Icon(Icons.person),
              label: Text(
                '${s.t('status')}${p.statPoints > 0 ? '  (+${p.statPoints})' : ''}',
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: () => _open(context, const SkillsScreen()),
              icon: const Icon(Icons.auto_awesome),
              label: Text(s.t('skills')),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: () => _open(context, const InventoryScreen()),
              icon: const Icon(Icons.inventory_2),
              label: Text(s.t('inventory')),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: () => _open(context, const SettingsScreen()),
              icon: const Icon(Icons.settings),
              label: Text(s.t('settings')),
            ),
            if (s.canAwakenOverlord) ...[
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () {
                  s.awakenOverlord();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        s.tx(
                          'You awakened as System Overlord!',
                          'به‌عنوان فرمانروای سامانه بیدار شدی!',
                        ),
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.workspace_premium),
                label: Text(
                  s.tx('Awaken System Overlord', 'بیداری فرمانروای سامانه'),
                ),
              ),
            ],
            if (s.canStartNewGamePlus) ...[
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () {
                  s.startNewGamePlus();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        s.tx(
                          'New Game+ started: enemies are stronger, rewards are bigger.',
                          'بازی جدید+ آغاز شد: دشمنان قوی‌تر و پاداش‌ها بیشتر.',
                        ),
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.replay),
                label: Text(s.tx('Start New Game+', 'شروع بازی جدید+')),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
