import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/app_theme.dart';
import '../services/app_state.dart';
import 'class_select_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _confirmReset(BuildContext context, AppState s) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('reset')),
        content: Text(
          s.tx(
            'This deletes your hunter and all progress. This cannot be undone.',
            'شکارچی و تمام پیشرفتت حذف می‌شود. این کار قابل بازگشت نیست.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(s.tx('Cancel', 'انصراف')),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(
              s.tx('Delete', 'حذف'),
              style: const TextStyle(color: AppColors.crimson),
            ),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await s.resetProgress();
    if (!context.mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const ClassSelectScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(s.t('settings'))),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            s.t('language'),
            style: const TextStyle(fontSize: 18, color: AppColors.gold),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    backgroundColor: s.lang == 'en' ? AppColors.blue : null,
                  ),
                  onPressed: () => s.setLang('en'),
                  child: const Text('English'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    backgroundColor: s.lang == 'fa' ? AppColors.blue : null,
                  ),
                  onPressed: () => s.setLang('fa'),
                  child: const Text('فارسی'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 30),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.crimson),
            onPressed: () => _confirmReset(context, s),
            icon: const Icon(Icons.delete_forever),
            label: Text(s.t('reset')),
          ),
          const SizedBox(height: 30),
          Text(
            s.tx(
              'Solo Ascent v1.0.0 - Lord Studio.\nProgress is saved automatically on this device after every fight.',
              'صعود تنها نسخه ۱.۰.۰ - Lord Studio.\nپیشرفت بعد از هر نبرد به‌طور خودکار روی همین دستگاه ذخیره می‌شود.',
            ),
            style: const TextStyle(color: Colors.white54),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
