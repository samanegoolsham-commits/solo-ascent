import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/items_data.dart';
import '../data/skills_data.dart';
import '../data/system_weapons_data.dart';
import '../l10n/app_theme.dart';
import '../services/app_state.dart';
import '../widgets/hp_bar.dart';
import '../widgets/tag_chip.dart';
import 'result_screen.dart';

class CombatScreen extends StatelessWidget {
  const CombatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final e = s.enemy;
    if (e == null) return const Scaffold(body: SizedBox.shrink());
    if (!s.inCombat) return const ResultScreen();

    final name = s.fa ? e.nameFa : e.nameEn;
    final p = s.player;
    final logLines = s.combatLog;
    final recent = logLines.length > 12
        ? logLines.sublist(logLines.length - 12)
        : logLines;
    final btnWidth = (MediaQuery.of(context).size.width - 32 - 8) / 2;

    final enemyTags = <Widget>[
      if (e.boss) TagChip(s.tx('BOSS', 'غول اصلی'), AppColors.crimson),
      if (e.elite) TagChip(s.tx('ELITE', 'نخبه'), AppColors.gold),
      if (s.enraged) TagChip(s.tx('ENRAGED', 'خشمگین'), Colors.orange),
      if (s.enemySkip > 0)
        TagChip(s.tx('DISABLED', 'ناتوان'), Colors.lightBlueAccent),
      if (s.enemyPoison > 0)
        TagChip(s.tx('POISONED', 'مسموم'), Colors.greenAccent),
    ];
    final playerTags = <Widget>[
      if (s.playerPoison > 0)
        TagChip(s.tx('POISONED', 'مسموم'), Colors.greenAccent),
      if (s.playerSkip > 0)
        TagChip(s.tx('STUNNED', 'گیج'), Colors.lightBlueAccent),
    ];

    return PopScope(
      canPop: false,
      child: Scaffold(
        appBar: AppBar(
          title: Text(s.tx('Gate Combat', 'نبرد دروازه')),
          automaticallyImplyLeading: false,
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Icon(
                          e.boss ? Icons.whatshot : Icons.crisis_alert,
                          size: 60,
                          color: AppColors.crimson,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          name,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          '${s.tx('Lv', 'سطح')} ${e.level}',
                          style: const TextStyle(color: AppColors.gold),
                        ),
                        const SizedBox(height: 6),
                        Wrap(spacing: 6, runSpacing: 6, children: enemyTags),
                        const SizedBox(height: 14),
                        HpBar(
                          label: name,
                          value: s.enemyHp,
                          max: s.enemyMaxHp,
                          color: AppColors.hp,
                        ),
                        const SizedBox(height: 16),
                        HpBar(
                          label: s.tx('Hunter HP', 'سلامتی شکارچی'),
                          value: p.hp,
                          max: p.maxHp,
                          color: Colors.green,
                        ),
                        const SizedBox(height: 8),
                        HpBar(
                          label: s.tx('MP', 'مانا'),
                          value: p.mp,
                          max: p.maxMp,
                          color: AppColors.mp,
                        ),
                        if (playerTags.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Wrap(spacing: 6, runSpacing: 6, children: playerTags),
                        ],
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 120,
                  width: double.infinity,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListView(
                    reverse: true,
                    children: [
                      for (final line in recent.reversed)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2),
                          child: Text(
                            line,
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 13,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  alignment: WrapAlignment.center,
                  children: [
                    _action(
                      btnWidth,
                      s.tx('Attack', 'حمله'),
                      Icons.flash_on,
                      () => s.basicAttack(),
                    ),
                    _action(
                      btnWidth,
                      s.tx('Skill', 'مهارت'),
                      Icons.auto_awesome,
                      () => _pickSkill(context, s),
                    ),
                    _action(
                      btnWidth,
                      s.tx('Item', 'آیتم'),
                      Icons.medication,
                      () => _pickItem(context, s),
                    ),
                    _action(
                      btnWidth,
                      s.tx('System Weapon', 'سلاح سامانه'),
                      Icons.gavel,
                      () => _pickWeapon(context, s),
                    ),
                    _action(
                      btnWidth,
                      s.tx('Flee', 'فرار'),
                      Icons.directions_run,
                      () => s.flee(),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _action(double width, String text, IconData icon, VoidCallback onTap) {
    return SizedBox(
      width: width,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 18),
        label: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
    );
  }

  void _pickSkill(BuildContext context, AppState s) {
    final tiles = <Widget>[];
    for (final x in skills) {
      if (!s.player.skills.contains(x.id)) continue;
      final cd = s.cooldownOf(x.id);
      final enoughMp = s.player.mp >= x.mpCost;
      final enabled = cd == 0 && enoughMp;
      tiles.add(
        ListTile(
          enabled: enabled,
          title: Text(s.fa ? x.nameFa : x.nameEn),
          subtitle: Text(s.fa ? x.descFa : x.descEn),
          trailing: Text(
            cd > 0
                ? '${s.tx('CD', 'انتظار')} $cd'
                : '${x.mpCost} ${s.tx('MP', 'مانا')}',
          ),
          onTap: enabled
              ? () {
                  Navigator.pop(context);
                  s.useSkill(x);
                }
              : null,
        ),
      );
    }
    _showPicker(
      context,
      s.tx('Choose a skill', 'یک مهارت انتخاب کن'),
      tiles,
      s.tx('No skills yet.', 'هنوز مهارتی نداری.'),
    );
  }

  void _pickItem(BuildContext context, AppState s) {
    final tiles = <Widget>[];
    for (final x in items) {
      final have = s.player.inventory[x.id] ?? 0;
      if (have <= 0) continue;
      tiles.add(
        ListTile(
          title: Text('${s.fa ? x.nameFa : x.nameEn}  ×$have'),
          subtitle: Text(s.fa ? x.descriptionFa : x.descriptionEn),
          onTap: () {
            Navigator.pop(context);
            s.useItem(x);
          },
        ),
      );
    }
    _showPicker(
      context,
      s.tx('Choose an item', 'یک آیتم انتخاب کن'),
      tiles,
      s.tx('Your bag has no consumables.', 'کوله‌پشتی‌ات اقلام مصرفی ندارد.'),
    );
  }

  void _pickWeapon(BuildContext context, AppState s) {
    final tiles = <Widget>[];
    for (final x in systemWeapons) {
      final owned = s.player.weapons.contains(x.id);
      final left = s.weaponUsesLeft(x.id);
      final enabled = owned && left > 0;
      String sub;
      if (!owned) {
        sub = s.tx('Not yet obtained', 'هنوز به‌دست نیامده');
      } else {
        final cost = x.hpCost > 0
            ? '${(x.hpCost * 100).round()}% HP'
            : '${x.mpCost} ${s.tx('MP', 'مانا')}';
        final uses = x.usesPerGate >= 99
            ? s.tx('unlimited', 'نامحدود')
            : '${s.tx('uses left', 'استفاده باقی‌مانده')}: $left';
        sub =
            '${s.fa ? x.abilityFa : x.abilityEn} • ×${x.multiplier} • $cost • $uses';
      }
      tiles.add(
        ListTile(
          enabled: enabled,
          leading: Icon(
            Icons.gavel,
            color: owned ? AppColors.gold : Colors.white24,
          ),
          title: Text(s.fa ? x.nameFa : x.nameEn),
          subtitle: Text(sub),
          onTap: enabled
              ? () {
                  Navigator.pop(context);
                  s.useWeapon(x);
                }
              : null,
        ),
      );
    }
    _showPicker(context, s.tx('System Weapons', 'سلاح‌های سامانه'), tiles, '');
  }

  void _showPicker(
    BuildContext context,
    String title,
    List<Widget> tiles,
    String emptyText,
  ) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.7,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(14),
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Flexible(
                child: tiles.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.all(24),
                        child: Text(emptyText),
                      )
                    : ListView(shrinkWrap: true, children: tiles),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
