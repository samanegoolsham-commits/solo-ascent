import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/items_data.dart';
import '../data/system_weapons_data.dart';
import '../l10n/app_theme.dart';
import '../services/app_state.dart';

class InventoryScreen extends StatelessWidget {
  const InventoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final p = s.player;
    final fragments = p.inventory['echo_fragment'] ?? 0;
    return Scaffold(
      appBar: AppBar(title: Text(s.t('inventory'))),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          Row(
            children: [
              const Icon(Icons.monetization_on, color: AppColors.gold),
              const SizedBox(width: 8),
              Text(
                '${s.tx('Gold', 'طلا')}: ${p.gold}',
                style: const TextStyle(fontSize: 18, color: AppColors.gold),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            s.tx('Consumables & Shop', 'اقلام مصرفی و فروشگاه'),
            style: const TextStyle(fontSize: 18, color: AppColors.gold),
          ),
          for (final x in items)
            Card(
              child: ListTile(
                leading: const Icon(Icons.medication, color: AppColors.crimson),
                title: Text(
                  '${s.fa ? x.nameFa : x.nameEn}  ×${p.inventory[x.id] ?? 0}',
                ),
                subtitle: Text(s.fa ? x.descriptionFa : x.descriptionEn),
                trailing: TextButton(
                  onPressed: p.gold >= x.price && (p.inventory[x.id] ?? 0) < 99
                      ? () => s.buy(x)
                      : null,
                  child: Text('${s.tx('Buy', 'خرید')} ${x.price}'),
                ),
              ),
            ),
          if (fragments > 0)
            Card(
              child: ListTile(
                leading: const Icon(
                  Icons.diamond,
                  color: Colors.lightBlueAccent,
                ),
                title: Text('${s.itemName('echo_fragment')}  ×$fragments'),
                subtitle: Text(
                  s.tx(
                    'Needed for the Architect\'s Judgement (3 fragments + 3 System Weapons).',
                    'برای حکم معمار لازم است (۳ قطعه + ۳ سلاح سامانه).',
                  ),
                ),
              ),
            ),
          const SizedBox(height: 14),
          Text(
            s.tx('System Weapons', 'سلاح‌های سامانه'),
            style: const TextStyle(fontSize: 18, color: AppColors.gold),
          ),
          for (final x in systemWeapons)
            Card(
              child: ListTile(
                leading: Icon(
                  Icons.gavel,
                  color: p.weapons.contains(x.id)
                      ? AppColors.gold
                      : Colors.white24,
                ),
                title: Text(s.fa ? x.nameFa : x.nameEn),
                subtitle: Text(
                  p.weapons.contains(x.id)
                      ? '${s.fa ? x.abilityFa : x.abilityEn} • ×${x.multiplier}'
                      : s.tx('Not yet obtained', 'هنوز به‌دست نیامده'),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
