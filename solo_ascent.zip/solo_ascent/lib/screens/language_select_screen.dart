import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/app_theme.dart';
import '../services/app_state.dart';
import 'home_hub_screen.dart';

class LanguageSelectScreen extends StatelessWidget {
  const LanguageSelectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.language, size: 72, color: AppColors.gold),
              const SizedBox(height: 16),
              const Text(
                'Choose Language / انتخاب زبان',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 40),
              _LangButton(
                label: 'English',
                selected: app.lang == 'en',
                onTap: () => app.setLang('en'),
              ),
              const SizedBox(height: 16),
              _LangButton(
                label: 'فارسی',
                selected: app.lang == 'fa',
                onTap: () => app.setLang('fa'),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.crimson,
                ),
                onPressed: () async {
                  await app.setLang(app.lang);
                  if (!context.mounted) return;
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => homeOrClassSelect(app)),
                  );
                },
                child: Text(app.t('continue')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LangButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _LangButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        minimumSize: const Size.fromHeight(60),
        backgroundColor: selected ? AppColors.blue : AppColors.surface,
        side: BorderSide(
          color: selected ? AppColors.gold : Colors.white24,
          width: 2,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      child: Text(
        label,
        style: const TextStyle(fontSize: 22, color: AppColors.text),
      ),
    );
  }
}
