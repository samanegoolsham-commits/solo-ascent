import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/quests_data.dart';
import '../l10n/app_theme.dart';
import '../models/quest.dart';
import '../services/app_state.dart';

class QuestsScreen extends StatefulWidget {
  const QuestsScreen({super.key});

  @override
  State<QuestsScreen> createState() => _QuestsScreenState();
}

class _QuestsScreenState extends State<QuestsScreen> {
  @override
  void initState() {
    super.initState();
    // Daily / weekly quests reset when the date changes.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<AppState>().refreshQuests();
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final daily = quests.where((q) => q.period == 'daily').toList();
    final weekly = quests.where((q) => q.period == 'weekly').toList();
    return Scaffold(
      appBar: AppBar(title: Text(s.t('quests'))),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          _header(s.tx('Daily Quests', 'ماموریت‌های روزانه')),
          for (final q in daily) _questTile(context, s, q),
          _header(s.tx('Weekly Quests', 'ماموریت‌های هفتگی')),
          for (final q in weekly) _questTile(context, s, q),
          _header(s.tx('Main Story', 'داستان اصلی')),
          for (final b in s.storyBosses)
            Card(
              child: ListTile(
                leading: Icon(
                  s.isDefeated(b.id) ? Icons.check_circle : Icons.flag,
                  color: s.isDefeated(b.id)
                      ? Colors.greenAccent
                      : AppColors.gold,
                ),
                title: Text(
                  '${s.tx('Defeat', 'شکست دادن')} ${s.fa ? b.nameFa : b.nameEn}',
                ),
                subtitle: Text(
                  '${s.tx('Recommended level', 'سطح پیشنهادی')} ${b.level}',
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _header(String text) => Padding(
    padding: const EdgeInsets.only(top: 12, bottom: 4),
    child: Text(
      text,
      style: const TextStyle(fontSize: 18, color: AppColors.gold),
    ),
  );

  Widget _questTile(BuildContext context, AppState s, Quest q) {
    final progress = s.questProgress(q);
    final claimed = s.questClaimed(q);
    final ready = s.questReady(q);
    final lvl = s.player.level;
    final reward =
        '${q.expPerLevel * lvl} EXP, ${q.goldPerLevel * lvl} ${s.tx('Gold', 'طلا')}'
        '${q.rewardItem.isNotEmpty ? ', ${s.itemName(q.rewardItem)} ×${q.rewardItemCount}' : ''}';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              s.fa ? q.nameFa : q.nameEn,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              reward,
              style: const TextStyle(color: Colors.white60, fontSize: 12),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                      value: (progress / q.target).clamp(0.0, 1.0).toDouble(),
                      minHeight: 8,
                      color: AppColors.gold,
                      backgroundColor: Colors.white12,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Text('$progress/${q.target}'),
                const SizedBox(width: 10),
                if (claimed)
                  const Icon(Icons.check_circle, color: Colors.greenAccent)
                else
                  TextButton(
                    onPressed: ready
                        ? () {
                            s.claimQuest(q);
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  s.tx('Reward claimed!', 'پاداش دریافت شد!'),
                                ),
                              ),
                            );
                          }
                        : null,
                    child: Text(s.tx('Claim', 'دریافت')),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
