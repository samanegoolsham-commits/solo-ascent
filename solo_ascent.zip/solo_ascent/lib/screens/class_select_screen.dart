import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/app_theme.dart';
import '../services/app_state.dart';
import 'home_hub_screen.dart';

class ClassSelectScreen extends StatefulWidget {
  const ClassSelectScreen({super.key});

  @override
  State<ClassSelectScreen> createState() => _ClassSelectScreenState();
}

class _ClassSelectScreenState extends State<ClassSelectScreen> {
  final TextEditingController _name = TextEditingController(text: 'Hunter');

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    const ids = ['Shadow Blade', 'Iron Colossus', 'Arcane Surge'];
    const icons = [Icons.bolt, Icons.shield, Icons.auto_awesome];
    final descEn = [
      'Agility and strength. Fast assassin with critical strikes.',
      'Vitality and strength. Heavy tank with high defense.',
      'Intelligence and mana. Elemental mage with strong skills.',
    ];
    final descFa = [
      'چابکی و قدرت. آدمکش سریع با ضربات بحرانی.',
      'سرزندگی و قدرت. تانک سنگین با دفاع بالا.',
      'هوش و مانا. جادوگر عنصری با مهارت‌های قدرتمند.',
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text(s.tx('Choose your path', 'مسیر خود را برگزینید')),
        actions: const [],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            s.tx(
              'The double-dungeon raid is over. Your party is gone. At the edge of death, the System awakens for you alone.',
              'یورش به سیاهچال دوگانه پایان یافته و همه‌ی هم‌تیمی‌هایت مرده‌اند. در آستانه‌ی مرگ، سامانه تنها برای تو بیدار می‌شود.',
            ),
            style: const TextStyle(color: Colors.white70, height: 1.6),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _name,
            maxLength: 16,
            decoration: InputDecoration(
              labelText: s.tx('Hunter name', 'نام شکارچی'),
              border: const OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          for (int i = 0; i < ids.length; i++)
            Card(
              child: ListTile(
                leading: Icon(icons[i], color: AppColors.gold, size: 34),
                title: Text(s.className(ids[i])),
                subtitle: Text(s.tx(descEn[i], descFa[i])),
                trailing: const Icon(Icons.chevron_right),
                onTap: () async {
                  await s.chooseClass(ids[i], _name.text);
                  if (!context.mounted) return;
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (_) => const HomeHubScreen()),
                    (route) => false,
                  );
                },
              ),
            ),
          const SizedBox(height: 12),
          Text(
            s.tx(
              'A fourth path, System Overlord, unlocks at level 50.',
              'مسیر چهارم، فرمانروای سامانه، در سطح ۵۰ باز می‌شود.',
            ),
            style: const TextStyle(color: Colors.white54),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
