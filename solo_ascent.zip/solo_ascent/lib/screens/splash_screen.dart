import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/app_theme.dart';
import '../services/app_state.dart';
import 'home_hub_screen.dart';
import 'language_select_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      final app = context.read<AppState>();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => app.langChosen
              ? homeOrClassSelect(app)
              : const LanguageSelectScreen(),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.auto_awesome, size: 96, color: AppColors.gold),
            const SizedBox(height: 16),
            const Text(
              'SOLO ASCENT',
              style: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.w900,
                color: AppColors.gold,
                letterSpacing: 4,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              context.tr('tagline'),
              style: const TextStyle(fontSize: 18, color: AppColors.text),
            ),
            const SizedBox(height: 32),
            const CircularProgressIndicator(color: AppColors.crimson),
          ],
        ),
      ),
    );
  }
}
