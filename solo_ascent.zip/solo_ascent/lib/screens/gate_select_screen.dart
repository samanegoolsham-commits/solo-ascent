import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/enemies_data.dart';
import '../l10n/app_theme.dart';
import '../models/enemy.dart';
import '../services/app_state.dart';
import 'combat_screen.dart';

class GateSelectScreen extends StatelessWidget {
  const GateSelectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    List<Enemy> group(bool Function(Enemy) test) {
      final list = enemies.where(test).toList();
      list.sort((a, b) => a.level.compareTo(b.level));
      return list;
    }

    final sections = <MapEntry<String, List<Enemy>>>[
      MapEntry(s.tx('Monsters', 'هیولاها'), group((e) => !e.boss && !e.elite)),
      MapEntry(s.tx('Elite Sub-Bosses', 'نخبگان'), group((e) => e.elite)),
      MapEntry(s.tx('Main Bosses', 'غول‌های اصلی'), group((e) => e.boss)),
    ];

    final children = <Widget>[
      Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(
          s.tx(
            'Gates far above your level are locked. Your HP and MP are restored when you enter.',
            'دروازه‌هایی که خیلی بالاتر از سطح تو هستند قفل‌اند. با ورود به دروازه سلامتی و مانایت پر می‌شود.',
          ),
          style: const TextStyle(color: Colors.white60),
        ),
      ),
    ];
    for (final sec in sections) {
      children.add(
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 4),
          child: Text(
            sec.key,
            style: const TextStyle(fontSize: 18, color: AppColors.gold),
          ),
        ),
      );
      for (final e in sec.value) {
        children.add(_gateTile(context, s, e));
      }
    }
    return Scaffold(
      appBar: AppBar(title: Text(s.t('gates'))),
      body: ListView(padding: const EdgeInsets.all(12), children: children),
    );
  }

  Widget _gateTile(BuildContext context, AppState s, Enemy e) {
    final locked = s.isLocked(e);
    final done = s.isDefeated(e.id);
    final tag = e.boss
        ? s.tx('BOSS', 'غول اصلی')
        : (e.elite ? s.tx('ELITE', 'نخبه') : s.tx('MONSTER', 'هیولا'));
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: e.boss ? AppColors.crimson : const Color(0xFF26314F),
          child: Icon(
            e.boss
                ? Icons.whatshot
                : (e.elite ? Icons.pest_control : Icons.bug_report),
            color: Colors.white,
          ),
        ),
        title: Text(s.fa ? e.nameFa : e.nameEn),
        subtitle: Text(
          '$tag • ${s.tx('Lv', 'سطح')} ${e.level} • ${e.maxHp} HP'
          '${locked ? '\n${s.tx('Recommended level', 'سطح پیشنهادی')}: ${e.level}' : ''}',
        ),
        isThreeLine: locked,
        trailing: Icon(
          locked
              ? Icons.lock
              : (done ? Icons.check_circle : Icons.chevron_right),
          color: locked
              ? Colors.white30
              : (done ? Colors.greenAccent : AppColors.gold),
        ),
        onTap: locked
            ? null
            : () {
                s.enterGate(e);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const CombatScreen()),
                );
              },
      ),
    );
  }
}
