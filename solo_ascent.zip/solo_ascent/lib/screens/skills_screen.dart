import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/skills_data.dart';
import '../l10n/app_theme.dart';
import '../models/skill.dart';
import '../services/app_state.dart';

class SkillsScreen extends StatelessWidget {
  const SkillsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final p = s.player;
    final cls = p.hunterClass;
    // Known skills, plus the not-yet-unlocked skills of the hunter's class.
    final shown = skills.where((x) {
      if (p.skills.contains(x.id)) return true;
      return x.unlockLevel > 0 &&
          (x.hunterClass == cls || cls == 'System Overlord');
    }).toList();
    shown.sort((a, b) {
      final ka = p.skills.contains(a.id) ? 0 : 1;
      final kb = p.skills.contains(b.id) ? 0 : 1;
      if (ka != kb) return ka.compareTo(kb);
      return a.unlockLevel.compareTo(b.unlockLevel);
    });
    return Scaffold(
      appBar: AppBar(title: Text(s.t('skills'))),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [for (final x in shown) _tile(s, x, p.skills.contains(x.id))],
      ),
    );
  }

  Widget _tile(AppState s, Skill x, bool known) {
    final details =
        '${s.fa ? x.descFa : x.descEn}\n'
        '×${x.multiplier} • ${x.mpCost} ${s.tx('MP', 'مانا')}'
        '${x.cooldown > 0 ? ' • ${s.tx('cooldown', 'انتظار')} ${x.cooldown}' : ''}';
    return Card(
      child: ListTile(
        isThreeLine: true,
        leading: Icon(
          known ? Icons.auto_awesome : Icons.lock,
          color: known ? AppColors.gold : Colors.white30,
        ),
        title: Text(s.fa ? x.nameFa : x.nameEn),
        subtitle: Text(
          known
              ? details
              : '${s.tx('Unlocks at level', 'باز شدن در سطح')} ${x.unlockLevel}\n$details',
        ),
      ),
    );
  }
}
