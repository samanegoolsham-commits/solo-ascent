import '../models/item.dart';

const items = <GameItem>[
  GameItem(
    id: 'health_potion',
    nameEn: 'Health Potion',
    nameFa: 'معجون سلامتی',
    descriptionEn: 'Restore 40% of max HP.',
    descriptionFa: '۴۰٪ از سلامتی کل را بازیابی کن.',
    healHp: 40,
    price: 30,
  ),
  GameItem(
    id: 'mana_potion',
    nameEn: 'Mana Potion',
    nameFa: 'معجون مانا',
    descriptionEn: 'Restore 50% of max MP.',
    descriptionFa: '۵۰٪ از مانای کل را بازیابی کن.',
    healMp: 50,
    price: 25,
  ),
  GameItem(
    id: 'antidote',
    nameEn: 'Antidote',
    nameFa: 'پادزهر',
    descriptionEn: 'Cure poison.',
    descriptionFa: 'مسمومیت را درمان کن.',
    price: 20,
  ),
];
