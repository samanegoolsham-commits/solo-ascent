@echo off
where gradle >NUL 2>NUL
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed. Install Flutter/Gradle, or run: flutter build apk --release 1>&2
exit /b 127
