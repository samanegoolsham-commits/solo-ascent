package com.soloascent.game
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
