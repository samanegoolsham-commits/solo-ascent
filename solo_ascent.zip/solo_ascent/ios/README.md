# iOS placeholder

The supplied project includes its complete Flutter/Dart source and Android target. Generate the native iOS Runner project on macOS with Xcode installed by running `flutter create . --platforms=ios` from the project root, then build with `flutter build ipa`.
