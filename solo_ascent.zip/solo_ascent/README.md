# Solo Ascent

Bilingual (English / Persian, RTL) portrait dark-fantasy turn-based RPG.
Classes, leveling and stat points, 19 gates (8 monsters, 6 elites, 5 main bosses),
status effects, 4 System Weapons, daily/weekly quests, shop, New Game+, local save.

## Build the APK

**Easiest (phone only):** upload this project to GitHub; `.github/workflows/build-apk.yml`
builds the APK automatically and publishes it under the repo's **Releases** page.

**On a computer:** install Flutter (3.29+) and the Android SDK, then:

```sh
flutter pub get
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk`

## Install

Open the APK on the phone, allow "Install unknown apps" for your browser/file manager,
and tap Install. All builds use the same signing key, so new versions update in place
and keep your save.

Font: Vazirmatn (SIL OFL, see assets/fonts/OFL.txt).
